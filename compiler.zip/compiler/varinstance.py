class VarInstance:
    def __init__(self):
        self.isGlobal = False
        self.isSelf = False
