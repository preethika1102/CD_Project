1
2
None
"123"
False
printf("%s\n", "")
