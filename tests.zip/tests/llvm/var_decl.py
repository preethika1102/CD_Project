x:str = "mystring"
y:int = 100
z:bool = True
printf("%s", x)
printf("%d", y)
printf("%d\n", z)
