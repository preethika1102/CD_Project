w:object = None
x:str = "mystring"
y:int = 1
z:bool = True
print(x)
print(y)
print(z)