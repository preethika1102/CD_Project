x:int = 1

x = 2

print(x)
