x = y = z = 1
