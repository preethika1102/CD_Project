True
False
1
None
"This is a string"
