def f()->int:
    return 3

x:int = f()