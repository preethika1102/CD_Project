x:int = 5
x = f(arg=x)