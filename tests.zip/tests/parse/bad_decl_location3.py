def f(x:int)->int:
    x = 2
    z:int = 2
    return x