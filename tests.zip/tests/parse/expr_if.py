3 if 1 > 2 else 4
