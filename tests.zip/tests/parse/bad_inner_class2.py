def f()->int:
    class C:
        pass