x:[int] = None
y:[int] = None
x = [1,2,3]
y = x[1:2]