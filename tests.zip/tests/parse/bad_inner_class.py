class A:
    class B:
        pass
    pass