x:int = 5
while True:
    x = 4
else:
    x = 3
