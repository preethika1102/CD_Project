def foo() -> int:
    return 1

foo()
