class A(object):
    pass

class B(object):
    pass

class C(A,B):
    pass