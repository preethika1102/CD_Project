def f(x:int)->int:
    if True:
        z:int = 2
    return x