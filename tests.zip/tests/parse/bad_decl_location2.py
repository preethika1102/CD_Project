x:int = 1
x = 2
y:int = 2