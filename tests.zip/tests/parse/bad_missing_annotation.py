def f(x)->int:
    return x