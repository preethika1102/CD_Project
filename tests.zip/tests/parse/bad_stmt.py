1 + 2
3 == 4 or (not False && True)
5 + 6
7 << 8
