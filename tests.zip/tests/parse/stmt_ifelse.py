if True:
    False
else:
    True

