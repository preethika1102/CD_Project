x:int = 42
y:int = 9

print(x // y)
print(x % y)
