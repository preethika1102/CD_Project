print(1 + 100)
