x:A = None

def foo(x:B) -> C:
    y:D = None
    return

pass
