def f() -> int:
  x:int = 1
  return x

print(f())
