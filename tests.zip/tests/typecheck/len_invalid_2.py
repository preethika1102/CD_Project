x:int = 1

print(len(x))
