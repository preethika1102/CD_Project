x:int = 1
y:bool = True

x = False
y = 2
z = 3
x = z = 4
x = z = None
