def f() -> int:
    while True:
        return 1
    return 0

print(f())
