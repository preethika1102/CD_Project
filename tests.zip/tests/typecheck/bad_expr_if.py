x: int = 0
x = "Hello" if 2 > 3 else 3
