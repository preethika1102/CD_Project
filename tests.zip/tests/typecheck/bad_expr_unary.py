not "Bad"
-True
-None
