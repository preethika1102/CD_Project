x:int = 42
print(x)
