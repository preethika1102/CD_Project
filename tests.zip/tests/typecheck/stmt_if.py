if False:
    pass
elif True:
    if 1 == 1:
        pass
else:
    pass
