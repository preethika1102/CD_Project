x:int = 0
y:object = 1
x = y = 42
print(x)
