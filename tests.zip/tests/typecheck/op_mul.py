print(6*9*2)
