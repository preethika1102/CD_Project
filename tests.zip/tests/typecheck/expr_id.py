x:int = 1

x - 1
