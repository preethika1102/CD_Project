print(True)
print(False)
