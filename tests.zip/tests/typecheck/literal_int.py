print(42)
print(65999)
