print(42 % 0)
