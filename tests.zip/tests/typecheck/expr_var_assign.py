x:int = 1
o:object = None

x = o = 42
