x:int = 0
while x < 100:
    x = x + 1
