1 + 2 * 3 > 13 // 3 % 2 or 1 != 1 and False == False

