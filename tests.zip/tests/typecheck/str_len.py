print(len("ChocoPy"))
