print(object() is None)
print(int())
print(str())
print(bool())
