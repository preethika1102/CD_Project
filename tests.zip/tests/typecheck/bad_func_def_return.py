def foo(x:str, y:bool) -> int:
    return None

def bar() -> bool:
    return 1

def baz() -> str:
    return

foo("Hello", False)
